import pandas as pd
import os
import seaborn as sns
import matplotlib.pyplot as plt

# Colors
colors = {
    "Color 1": "#016FEB",  # Bright Blue 
    "Color 2": "#00326A",  # Deep Navy Blue
    "Color 3": "#749AFF",  # Light Sky Blue
    "Color 4": "#9AA5D8",  # Soft Lavender Blue
    "Color 5": "#827742",  # Olive Brown
    "Color 6": "#463F0F"   # Dark Olive Green
}

figsizet = (7.12, 4.5)
# Change cwd
os.chdir("C:/Users/thier/00ETHZ/MS3/Biomicrofluidics/Project/Results")

# Load the data
filtered_file = 'scores_tbo_her2_run2_pydssp.csv'  # Replace with your local path
unfiltered_file = 'scores_tbo_her2_run2_standard.csv'  # Replace with your local path
filtered_data = pd.read_csv(filtered_file)
unfiltered_data = pd.read_csv(unfiltered_file)

# Apply filters to create concentrated datasets for both filtered and unfiltered
concentrated_filtered_data = filtered_data[
    (filtered_data['binder_aligned_rmsd'] < 3) &
    (filtered_data['plddt_binder'] > 80) &
    (filtered_data['plddt_total'] > 80)
]
concentrated_filtered_data['Filter'] = 'Filtered'

concentrated_unfiltered_data = unfiltered_data[
    (unfiltered_data['binder_aligned_rmsd'] < 3) &
    (unfiltered_data['plddt_binder'] > 80) &
    (unfiltered_data['plddt_total'] > 80)
]
concentrated_unfiltered_data['Filter'] = 'All'

# Combine datasets: filtered, unfiltered, and their concentrated versions
processed_data = pd.concat([
    filtered_data,
    unfiltered_data,
    concentrated_filtered_data,
    concentrated_unfiltered_data
], ignore_index=True)

# Custom color palette
palette = [colors["Color 1"], colors["Color 2"]]

# Set up the figure with 2 rows and 4 columns (2x4 grid of subplots)
fig, axs = plt.subplots(2, 4, figsize=(figsizet), gridspec_kw={'width_ratios': [2.8, 1, 2.8, 1]})

# List of metrics and corresponding labels
metrics = ['pae_interaction', 'binder_aligned_rmsd', 'plddt_total', 'plddt_binder']
metric_labels = [
    r'pAE$_{\text{Interaction}}$ / %',
    r'RMSD$_{\text{Binder}}$ / Å',
    r'pLDDT$_{\text{Total}}$ / %',
    r'pLDDT$_{\text{Binder}}$ / %'
]

# Font size for axis labels
label_fontsize = 8

# Font size for ticks and legend
tick_fontsize = 6
legend_fontsize = 7

# Plotting the first metric (pAE Interaction)
sns.histplot(
    data=processed_data, 
    x=metrics[0], 
    hue='Filter', 
    kde=True, 
    element='step', 
    stat='density', 
    common_norm=False,  
    palette=palette, 
    ax=axs[0, 0],
    legend=False,
    linewidth=0.5
)
axs[0, 0].set_xlim([21, 29])
axs[0, 0].set_xlabel(metric_labels[0], fontsize=label_fontsize)
axs[0, 0].set_ylabel('Density', fontsize=label_fontsize)
sns.boxplot(data=processed_data, x='Filter', y=metrics[0], palette=palette, ax=axs[0, 1], linewidth=0.5, fliersize=0.8)
axs[0, 1].set_ylim([21,29])
axs[0, 1].set_xlabel(' ', fontsize=label_fontsize)
axs[0, 1].set_ylabel(metric_labels[0], fontsize=label_fontsize)

# Access the KDE line for the first subplot and adjust its linewidth
for line in axs[0, 0].lines:
    line.set_linewidth(1)  # Adjust the line width for KDE plot

# Plotting the second metric (RMSD Binder)
sns.histplot(
    data=processed_data, 
    x=metrics[1], 
    hue='Filter', 
    kde=True, 
    element='step', 
    stat='density', 
    common_norm=False,  
    palette=palette, 
    ax=axs[0, 2],
    legend=False,
    linewidth=0.5
)

axs[0, 2].set_xlabel(metric_labels[1], fontsize=label_fontsize)
axs[0, 2].set_ylabel('Density', fontsize=label_fontsize)
sns.boxplot(data=processed_data, x='Filter', y=metrics[1], palette=palette, ax=axs[0, 3], linewidth=0.5, fliersize=0.8)
axs[0, 3].set_xlabel(' ', fontsize=label_fontsize)
axs[0, 3].set_ylabel(metric_labels[1], fontsize=label_fontsize)

# Access the KDE line for the second subplot and adjust its linewidth
for line in axs[0, 2].lines:
    line.set_linewidth(1)

# Plotting the third metric (pLDDT Total)
sns.histplot(
    data=processed_data, 
    x=metrics[2], 
    hue='Filter', 
    kde=True, 
    element='step', 
    stat='density', 
    common_norm=False,  
    palette=palette, 
    ax=axs[1, 0],
    legend=False,
    linewidth=0.5
)
axs[1, 0].set_xlabel(metric_labels[2], fontsize=label_fontsize)
axs[1, 0].set_ylabel('Density', fontsize=label_fontsize)
sns.boxplot(data=processed_data, x='Filter', y=metrics[2], palette=palette, ax=axs[1, 1], linewidth=0.5, fliersize=0.8)
axs[1, 1].set_xlabel(' ', fontsize=label_fontsize)
axs[1, 1].set_ylabel(metric_labels[2], fontsize=label_fontsize)

# Access the KDE line for the third subplot and adjust its linewidth
for line in axs[1, 0].lines:
    line.set_linewidth(1)

# Plotting the fourth metric (pLDDT Binder)
sns.histplot(
    data=processed_data, 
    x=metrics[3], 
    hue='Filter', 
    kde=True, 
    element='step', 
    stat='density', 
    common_norm=False,  
    palette=palette, 
    ax=axs[1, 2],
    legend=False,
    linewidth=0.5
)
axs[1, 2].set_xlabel(metric_labels[3], fontsize=label_fontsize)
axs[1, 2].set_ylabel('Density', fontsize=label_fontsize)
sns.boxplot(data=processed_data, x='Filter', y=metrics[3], palette=palette, ax=axs[1, 3], linewidth=0.5, fliersize=0.8)
axs[1, 3].set_xlabel(' ', fontsize=label_fontsize)
axs[1, 3].set_ylabel(metric_labels[3], fontsize=label_fontsize)

# Access the KDE line for the fourth subplot and adjust its linewidth
for line in axs[1, 2].lines:
    line.set_linewidth(1)

# Set the font size for ticks
for ax in axs.flat:
    ax.tick_params(axis='both', labelsize=tick_fontsize)

    # Adjust line width and marker size globally for all plots
    ax.tick_params(axis='both', which='major', width=0.5)  # Axis lines
    ax.tick_params(axis='both', which='minor', width=0.5)  # Minor ticks (if any)
    ax.spines['top'].set_linewidth(0.5)  # Top border line width
    ax.spines['right'].set_linewidth(0.5)  # Right border line width
    ax.spines['bottom'].set_linewidth(0.5)  # Bottom border line width
    ax.spines['left'].set_linewidth(0.5)  # Left border line width

# Adjust layout to avoid overlapping and reduce space
plt.subplots_adjust(wspace=-1.1, hspace=0)  # Reduce space between subplots (adjust values as needed)

# Save the figure with the specified dimensions
os.chdir("C:/Users/thier/00ETHZ/MS3/Biomicrofluidics/Project/Results/Plots")

# Adjust layout to avoid overlapping
plt.tight_layout()

# Save the figure with a specific DPI and tight bounding box
fig = plt.gcf()  # Get the current figure
fig.set_size_inches(figsizet)  # Set size in inches (18 cm by 13.5 cm)

# Save the figure as a PNG image with 300 DPI
plt.savefig('plots_60-60.png', dpi=300, bbox_inches='tight')

# Display the plot
plt.show()
