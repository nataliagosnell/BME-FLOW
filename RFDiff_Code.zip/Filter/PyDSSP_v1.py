# Import
import numpy as np
import os
import torch
import pydssp
from Bio.PDB import PDBParser

os.chdir("C:/Users/thier/00ETHZ/MS3/Biomicrofluidics/Project/Data/her2_outputs_100aa_run1/")

# Initialize the PDB parser
# Define the atom names to include
atoms_of_interest = {"N", "CA", "C", "O"}

# Initialize the PDB parser
parser = PDBParser(QUIET=True)

# Parse the PDB file
structure = parser.get_structure("protein", "her2_outputs_100aa_run1_0009.pdb")

# Extract and filter atomic coordinates for chain "A"
batch_coordinates = []

for model in structure:  # Iterate through models (usually one in most PDBs)
    for chain in model:  # Iterate through chains
        if chain.id == "A":  # Filter for chain identifier "A"
            chain_coordinates = []
            for residue in chain:  # Iterate through residues
                residue_coords = []
                for atom in residue:  # Iterate through atoms
                    if atom.get_name() in atoms_of_interest:
                        residue_coords.append(atom.get_coord())
                # Append residue_coords only if all atoms of interest are present
                if len(residue_coords) == len(atoms_of_interest):
                    chain_coordinates.append(residue_coords)
            if chain_coordinates:  # Add to batch only if the chain has valid residues
                batch_coordinates.append(chain_coordinates)

# Convert the batch coordinates into a PyTorch tensor
# Tensor shape: [batch (number_of_chains), number_of_residues, 5, 3

tensor = torch.tensor(batch_coordinates)

#print(tensor.shape)
#print(tensor)

# Print the tensor for verification
# print("Tensor shape:", coord_tensor.shape)
# print("Tensor:", tensor)
dssp = pydssp.assign(tensor, out_type='c3')
# print(dssp)

dssp_array = np.array(dssp)
dssp_seq = dssp_array.flatten()
# print(dssp_seq)

diff_structures = 0
current_structure = None
gap_length = 0
has_gap = False


for structure in dssp_seq:
    if structure == '-':
        gap_length += 1
        has_gap = True
        current_structure=None
        #print(gap_length)

    else:
        if has_gap and gap_length > 4:
            if structure in {'H', 'E'} and structure != current_structure:
                diff_structures += 1
                current_structure = structure
                gap_length = 0  # Reset gap
                has_gap = False

        elif structure in {'H', 'E'} and structure != current_structure:
            diff_structures += 1
            current_structure = structure

print(f"Diff Struc: {diff_structures}")
