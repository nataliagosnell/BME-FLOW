# Import
import numpy as np
import os
import torch
import pydssp
from Bio.PDB import PDBParser
import sys

def main(pdb_path):

    output_file_name = "filtered_outputs.txt"
    output_file = os.path.join(pdb_path, output_file_name)

    # Initialize the PDB parser
    atoms_of_interest = {"N", "CA", "C", "O"}
    parser = PDBParser(QUIET=True)

    promising_files = []

    for pdb_file in os.listdir(pdb_path):
        if pdb_file.endswith(".pdb"):
            pdb_link = os.path.join(pdb_path, pdb_file)
            # print(f"Processing: {pdb_link}")

            try:
                # Parse the PDB file
                structure = parser.get_structure("protein", pdb_link)

                # Extract and filter atomic coordinates for chain "A"
                batch_coordinates = []
                for model in structure:
                    for chain in model:
                        if chain.id == "A":  # Filter for chain identifier "A"
                            chain_coordinates = []
                            for residue in chain:
                                residue_coords = []
                                for atom in residue:
                                    if atom.get_name() in atoms_of_interest:
                                        residue_coords.append(atom.get_coord())
                                if len(residue_coords) == len(atoms_of_interest):
                                    chain_coordinates.append(residue_coords)
                            if chain_coordinates:
                                batch_coordinates.append(chain_coordinates)

                if not batch_coordinates:
                    continue

                tensor = torch.tensor(batch_coordinates)

                # Use DSSP to assign secondary structure
                dssp = pydssp.assign(tensor, out_type='c3')
                dssp_array = np.array(dssp)
                dssp_seq = dssp_array.flatten()

                # Check for at least two segments of 'H' or 'E' separated by 5+ '-'
                diff_structures = 0
                current_structure = None
                gap_length = 0
                has_gap = False

                for structure in dssp_seq:
                    if structure == '-':
                        gap_length += 1
                        has_gap = True
                        current_structure = None
                    else:
                        if has_gap and gap_length >= 3:
                            if structure in {'H', 'E'} and structure != current_structure:
                                diff_structures += 1
                                current_structure = structure
                            gap_length = 0  # Reset gap
                            has_gap = False
                        elif structure in {'H', 'E'} and structure != current_structure:
                            diff_structures += 1
                            current_structure = structure

                # File is promising if it meets the conditions
                if diff_structures > 1:
                    promising_files.append(pdb_file)

            except Exception as e:
                print(f"Error processing {pdb_file}: {e}")

    # Write promising files to output file
    with open(output_file, "w") as f:
        for file in promising_files:
            f.write(file + "\n")

    print(f"Promising files written to {output_file}")

if __name__ == '__main__':

    if len(sys.argv) < 1:
        print("USAGE: pydssp_v2.py \"DIR_PDBS\"")
        exit(1)
    elif len(sys.argv) >2:
        print("ERROR: only one directory at a time!")
        print("USAGE: pydssp_v2.py \"DIR_PDBS\"")
        exit(1)

    main(sys.argv[1])