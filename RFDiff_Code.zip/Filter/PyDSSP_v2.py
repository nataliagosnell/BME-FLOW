# Import
import numpy as np
import os
import torch
import pydssp
from Bio.PDB import PDBParser
import sys

def main(pdb_path):

    output_file_name = "filtered_outputs.txt"
    output_file = os.path.join(pdb_path, output_file_name)

    # Initialize the PDB parser
    # Define the atom names to include
    atoms_of_interest = {"N", "CA", "C", "O"}

    # Initialize the PDB parser
    parser = PDBParser(QUIET=True)

    promising_files = []

    for pdb_file in os.listdir(pdb_path):

        if pdb_file.endswith(".pdb"):

            pdb_link = os.path.join(pdb_path, pdb_file)
            print(pdb_link)

            # Parse the PDB file
            structure = parser.get_structure("protein", pdb_link)

            # Extract and filter atomic coordinates for chain "A"
            batch_coordinates = []

            for model in structure:  # Iterate through models (usually one in most PDBs)
                for chain in model:  # Iterate through chains
                    if chain.id == "A":  # Filter for chain identifier "A"
                        chain_coordinates = []
                        for residue in chain:  # Iterate through residues
                            residue_coords = []
                            for atom in residue:  # Iterate through atoms
                                if atom.get_name() in atoms_of_interest:
                                    residue_coords.append(atom.get_coord())
                            # Append residue_coords only if all atoms of interest are present
                            if len(residue_coords) == len(atoms_of_interest):
                                chain_coordinates.append(residue_coords)
                        if chain_coordinates:  # Add to batch only if the chain has valid residues
                            batch_coordinates.append(chain_coordinates)

            # Convert the batch coordinates into a PyTorch tensor
            if not batch_coordinates:
                continue

            # Tensor shape: [batch (number_of_chains), number_of_residues, 5, 3]
            tensor = torch.tensor(batch_coordinates)

            #print(tensor.shape)
            #print(tensor)

            # Print the tensor for verification
            # print("Tensor shape:", coord_tensor.shape)
            # print("Tensor:", tensor)
            try:
                dssp = pydssp.assign(tensor, out_type='c3')
            except Exception as e: 
                print(f"Error in {pdb_file}: {e}")


            dssp_array = np.array(dssp)
            dssp_seq = dssp_array.flatten()
            

            diff_structures = 0
            current_structure = None

            for structure in dssp_seq:
                if structure != '-':
                    if structure != current_structure:
                        diff_structures += 1
                        current_structure = structure
                
                else:
                    current_structure = structure

            if diff_structures > 1:
                promising_files.append(pdb_file)

    # Write promising files to output file
    with open(output_file, "w") as f:
        for file in promising_files:
            f.write(file + "\n")

    print(f"Promising files written to {output_file}")


if __name__ == '__main__':

    if len(sys.argv) < 1:
        print("USAGE: pydssp_v2.py \"DIR_PDBS\"")
        exit(1)
    elif len(sys.argv) >2:
        print("ERROR: only one directory at a time!")
        print("USAGE: pydssp_v2.py \"DIR_PDBS\"")
        exit(1)

    main(sys.argv[1])
